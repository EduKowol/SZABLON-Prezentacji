# Wariant lokalny

Paczka zawiera `latexmkrc`. Kompiluj poleceniem `latexmk main.tex`.
Gotowy dokument znajdzie się w `build/main.pdf`.
