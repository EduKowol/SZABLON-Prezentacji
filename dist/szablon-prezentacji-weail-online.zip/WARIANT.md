# Wariant internetowy

Paczka jest przeznaczona do Prism, Overleaf lub podobnego edytora. Ustaw
`main.tex` jako dokument główny i wybierz kompilator LuaLaTeX.
