# Wariant internetowy

Ta paczka jest przeznaczona do Prism, Overleaf lub podobnego edytora. Nie zawiera
lokalnego pliku `latexmkrc`. Po imporcie ustaw:

- dokument główny: `main.tex`;
- kompilator: LuaLaTeX.

Katalogiem plików pomocniczych zarządza platforma internetowa. Lokalna
instalacja Perla nie jest potrzebna. Jeśli wcześniej wykonano kompilację przez
pdfLaTeX, po zmianie silnika użyj funkcji pełnej kompilacji od początku
(`Recompile from scratch`) albo wyczyść pliki pomocnicze projektu.
